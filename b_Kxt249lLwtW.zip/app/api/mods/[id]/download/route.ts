import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Increment download count
    const { data: mod, error } = await supabase
      .from("mods")
      .select("downloads, file_url")
      .eq("id", id)
      .single()

    if (error || !mod) {
      return NextResponse.json({ error: "Mod not found" }, { status: 404 })
    }

    // Update download count
    await supabase
      .from("mods")
      .update({ downloads: mod.downloads + 1 })
      .eq("id", id)

    return NextResponse.json({ file_url: mod.file_url })
  } catch (error) {
    console.error("Error downloading mod:", error)
    return NextResponse.json({ error: "Download failed" }, { status: 500 })
  }
}
