import { LeftSidebar } from "@/components/left-sidebar"
import { RightSidebar } from "@/components/right-sidebar"
import { FeaturedRelease } from "@/components/featured-release"
import { MobileNav } from "@/components/mobile-nav"
import { createClient } from "@/lib/supabase/server"
import { HomeClient } from "@/components/home-client"

export default async function Home() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  let profile = null
  if (user) {
    const { data } = await supabase
      .from("profiles")
      .select("username")
      .eq("id", user.id)
      .single()
    profile = data
  }

  const userData = user ? {
    id: user.id,
    email: user.email,
    username: profile?.username,
  } : null

  return (
    <div className="min-h-screen bg-background">
      <HomeClient user={userData}>
        <div className="flex">
          <LeftSidebar />
          
          {/* Main Content */}
          <main className="flex-1 min-w-0 pb-20 lg:pb-4">
            <div className="p-4 max-w-4xl mx-auto">
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-xl font-bold text-foreground">
                    <span className="text-primary neon-primary">Trending</span> Mods
                  </h1>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Discover the hottest mods in the community
                  </p>
                </div>
              </div>

              {/* Featured */}
              <FeaturedRelease />

              {/* Mod Grid will be rendered by HomeClient */}
            </div>
          </main>

          <RightSidebar />
        </div>

        <MobileNav />
      </HomeClient>
    </div>
  )
}
