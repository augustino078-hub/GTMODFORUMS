"use client"

import { Package, Upload, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ModCard } from "./mod-card"
import useSWR from "swr"
import { formatDistanceToNow } from "date-fns"

interface Mod {
  id: string
  name: string
  description: string
  file_url: string
  thumbnail_url: string | null
  downloads: number
  created_at: string
  updated_at: string
  profiles: {
    username: string
    avatar_url: string | null
    is_verified: boolean
  }
  tags: string[]
}

interface ModGridProps {
  onUploadClick?: () => void
}

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function ModGrid({ onUploadClick }: ModGridProps) {
  const { data, error, isLoading } = useSWR<{ mods: Mod[] }>("/api/mods", fetcher, {
    refreshInterval: 30000,
  })

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4">
        <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
        <p className="text-sm text-muted-foreground">Loading mods...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4">
        <p className="text-sm text-destructive">Failed to load mods</p>
      </div>
    )
  }

  const mods = data?.mods || []

  if (mods.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4">
        <div className="w-16 h-16 rounded-full bg-card border border-border flex items-center justify-center mb-4">
          <Package className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">No mods yet</h3>
        <p className="text-sm text-muted-foreground text-center max-w-sm mb-4">
          Be the first to upload a mod and share it with the community.
        </p>
        <Button 
          className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
          onClick={onUploadClick}
        >
          <Upload className="h-4 w-4" />
          Upload Mod
        </Button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {mods.map((mod) => (
        <ModCard
          key={mod.id}
          id={mod.id}
          name={mod.name}
          creator={mod.profiles?.username || "Unknown"}
          description={mod.description}
          thumbnail_url={mod.thumbnail_url}
          downloads={mod.downloads}
          tags={mod.tags || []}
          isVerified={mod.profiles?.is_verified}
          updatedTime={formatDistanceToNow(new Date(mod.updated_at), { addSuffix: true })}
        />
      ))}
    </div>
  )
}
