"use client"

import { Search, Upload, Bell, User, Menu, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface NavbarProps {
  user: {
    id: string
    email?: string
    username?: string
  } | null
  onUploadClick?: () => void
}

export function Navbar({ user, onUploadClick }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push("/")
    router.refresh()
  }

  return (
    <nav className="sticky top-0 z-50 h-14 border-b border-border bg-secondary/80 backdrop-blur-md">
      <div className="flex h-full items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <button 
            className="lg:hidden p-1.5 hover:bg-card rounded-md transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="h-5 w-5" />
          </button>
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">G</span>
            </div>
            <span className="font-bold text-lg hidden sm:block">
              <span className="text-primary neon-primary">Gorilla</span>
              <span className="text-foreground">Hub</span>
            </span>
          </Link>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-md mx-4 hidden md:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search mods, creators, tags..." 
              className="pl-9 bg-card border-border h-9 focus:border-primary focus:ring-primary/20"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button className="md:hidden p-2 hover:bg-card rounded-md transition-colors">
            <Search className="h-5 w-5 text-muted-foreground" />
          </button>
          
          {user ? (
            <>
              <Button 
                size="sm" 
                className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5 hidden sm:flex"
                onClick={onUploadClick}
              >
                <Upload className="h-4 w-4" />
                <span>Upload</span>
              </Button>
              
              <button className="relative p-2 hover:bg-card rounded-md transition-colors">
                <Bell className="h-5 w-5 text-muted-foreground" />
              </button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 p-1.5 hover:bg-card rounded-md transition-colors">
                    <div className="w-7 h-7 rounded-full bg-highlight flex items-center justify-center">
                      <span className="text-highlight-foreground text-xs font-bold">
                        {user.username?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || "U"}
                      </span>
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48 bg-card border-border">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium text-foreground">
                      {user.username || "User"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {user.email}
                    </p>
                  </div>
                  <DropdownMenuSeparator className="bg-border" />
                  <DropdownMenuItem 
                    onClick={handleLogout}
                    className="text-destructive focus:text-destructive cursor-pointer"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/auth/login">Sign In</Link>
              </Button>
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
                <Link href="/auth/sign-up">Sign Up</Link>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Search - shown when menu is open */}
      {mobileMenuOpen && (
        <div className="md:hidden p-3 border-t border-border bg-secondary">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search mods..." 
              className="pl-9 bg-card border-border h-9"
            />
          </div>
        </div>
      )}
    </nav>
  )
}
