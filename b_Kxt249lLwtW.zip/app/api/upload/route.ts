import { put } from "@vercel/blob"
import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File
    const type = formData.get("type") as string // "mod" or "thumbnail"

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    if (type === "mod") {
      const validExtensions = [".zip", ".dll", ".json"]
      const ext = file.name.toLowerCase().slice(file.name.lastIndexOf("."))
      if (!validExtensions.includes(ext)) {
        return NextResponse.json(
          { error: "Invalid mod file type. Only .zip, .dll, and .json files are allowed." },
          { status: 400 }
        )
      }
    } else if (type === "thumbnail") {
      const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
      if (!validTypes.includes(file.type)) {
        return NextResponse.json(
          { error: "Invalid image type. Only JPEG, PNG, GIF, and WebP are allowed." },
          { status: 400 }
        )
      }
    }

    // Create unique filename
    const timestamp = Date.now()
    const folder = type === "mod" ? "mods" : "thumbnails"
    const filename = `${folder}/${user.id}/${timestamp}-${file.name}`

    const blob = await put(filename, file, {
      access: "public",
    })

    return NextResponse.json({ url: blob.url })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Upload failed" }, { status: 500 })
  }
}
