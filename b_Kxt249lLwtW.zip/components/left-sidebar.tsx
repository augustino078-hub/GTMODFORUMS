"use client"

import { 
  TrendingUp, 
  Sparkles, 
  Star, 
  Zap, 
  Gamepad2, 
  Wrench, 
  Megaphone, 
  BookOpen, 
  HelpCircle,
  Users
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"

interface SidebarItem {
  icon: React.ReactNode
  label: string
  count?: number
  isActive?: boolean
}

interface SidebarSection {
  title: string
  items: SidebarItem[]
}

const sections: SidebarSection[] = [
  {
    title: "BROWSE",
    items: [
      { icon: <TrendingUp className="h-4 w-4" />, label: "Trending" },
      { icon: <Sparkles className="h-4 w-4" />, label: "New" },
      { icon: <Star className="h-4 w-4" />, label: "Popular" },
    ]
  },
  {
    title: "MODS",
    items: [
      { icon: <Zap className="h-4 w-4" />, label: "Movement" },
      { icon: <Gamepad2 className="h-4 w-4" />, label: "Gameplay" },
      { icon: <Wrench className="h-4 w-4" />, label: "Utilities" },
    ]
  },
  {
    title: "COMMUNITY",
    items: [
      { icon: <Megaphone className="h-4 w-4" />, label: "Releases" },
      { icon: <BookOpen className="h-4 w-4" />, label: "Tutorials" },
      { icon: <HelpCircle className="h-4 w-4" />, label: "Support" },
    ]
  }
]

export function LeftSidebar() {
  const [activeItem, setActiveItem] = useState("Trending")

  return (
    <aside className="hidden lg:block w-52 shrink-0 border-r border-border bg-secondary/50 overflow-y-auto">
      <div className="py-3 px-2">
        {/* Online Users */}
        <div className="flex items-center gap-2 px-3 py-2 mb-3 rounded-md bg-card/50">
          <div className="relative">
            <Users className="h-4 w-4 text-primary" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-primary rounded-full animate-pulse-online" />
          </div>
          <span className="text-xs text-muted-foreground">
            <span className="text-primary font-medium">0</span> online
          </span>
        </div>

        {sections.map((section) => (
          <div key={section.title} className="mb-4">
            <h3 className="text-[10px] font-semibold text-muted-foreground px-3 mb-1.5 tracking-wider">
              {section.title}
            </h3>
            <div className="space-y-0.5">
              {section.items.map((item) => (
                <button
                  key={item.label}
                  onClick={() => setActiveItem(item.label)}
                  className={cn(
                    "w-full flex items-center justify-between px-3 py-1.5 rounded-md text-sm transition-all duration-200",
                    activeItem === item.label 
                      ? "bg-primary/10 text-primary border-l-2 border-primary" 
                      : "text-muted-foreground hover:text-foreground hover:bg-card/50"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "transition-colors",
                      activeItem === item.label ? "text-primary" : ""
                    )}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>
                  {item.count && (
                    <span className={cn(
                      "text-xs px-1.5 py-0.5 rounded-full",
                      activeItem === item.label 
                        ? "bg-primary/20 text-primary" 
                        : "bg-card text-muted-foreground"
                    )}>
                      {item.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Trending Tags */}
        <div className="mt-6 px-3">
          <h3 className="text-[10px] font-semibold text-muted-foreground mb-2 tracking-wider">
            TRENDING TAGS
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {["cosmetics", "speed", "physics", "menu", "tools"].map((tag) => (
              <span 
                key={tag}
                className="text-xs px-2 py-0.5 rounded-full bg-card text-muted-foreground hover:bg-card/80 hover:text-accent cursor-pointer transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </aside>
  )
}
