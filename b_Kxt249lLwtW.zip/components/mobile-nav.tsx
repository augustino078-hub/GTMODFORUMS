"use client"

import { Home, TrendingUp, Upload, MessageSquare, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"

const navItems = [
  { icon: Home, label: "Home" },
  { icon: TrendingUp, label: "Trending" },
  { icon: Upload, label: "Upload" },
  { icon: MessageSquare, label: "Community" },
  { icon: User, label: "Profile" },
]

export function MobileNav() {
  const [active, setActive] = useState("Home")

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-secondary/95 backdrop-blur-md">
      <div className="flex items-center justify-around h-14">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = active === item.label
          const isUpload = item.label === "Upload"

          return (
            <button
              key={item.label}
              onClick={() => setActive(item.label)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 w-full h-full transition-colors",
                isUpload 
                  ? "text-primary" 
                  : isActive 
                    ? "text-primary" 
                    : "text-muted-foreground hover:text-foreground"
              )}
            >
              <div className={cn(
                "p-1.5 rounded-lg transition-colors",
                isUpload && "bg-primary/10",
                isActive && !isUpload && "bg-primary/10"
              )}>
                <Icon className={cn(
                  "h-5 w-5",
                  isUpload && "h-6 w-6"
                )} />
              </div>
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
