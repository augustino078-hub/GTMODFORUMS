import { Zap, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"

export function FeaturedRelease() {
  return (
    <div className="relative overflow-hidden rounded-lg border border-border bg-card/50 p-4 mb-4">
      {/* Featured Badge */}
      <div className="absolute top-0 right-0">
        <div className="bg-muted text-muted-foreground text-[10px] font-bold px-3 py-1 rounded-bl-lg flex items-center gap-1">
          <Zap className="h-3 w-3" />
          FEATURED
        </div>
      </div>

      <div className="flex flex-col items-center justify-center py-4 text-center">
        <p className="text-sm text-muted-foreground mb-3">
          No featured mod yet. Upload a mod to get featured!
        </p>
        <Button size="sm" variant="outline" className="gap-2">
          <Upload className="h-3.5 w-3.5" />
          Upload Mod
        </Button>
      </div>
    </div>
  )
}
