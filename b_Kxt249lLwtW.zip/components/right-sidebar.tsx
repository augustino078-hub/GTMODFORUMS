import { MessageSquare, Upload, Crown } from "lucide-react"

export function RightSidebar() {
  return (
    <aside className="hidden xl:block w-64 shrink-0 border-l border-border bg-secondary/50 overflow-y-auto">
      <div className="py-3 px-3 space-y-5">
        {/* Recent Activity */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="h-3.5 w-3.5 text-accent" />
            <h3 className="text-xs font-semibold text-muted-foreground tracking-wider">
              RECENT ACTIVITY
            </h3>
          </div>
          <div className="p-3 rounded-md bg-card/30 border border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              No recent activity
            </p>
          </div>
        </section>

        {/* Top Creators */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <Crown className="h-3.5 w-3.5 text-highlight" />
            <h3 className="text-xs font-semibold text-muted-foreground tracking-wider">
              TOP CREATORS
            </h3>
          </div>
          <div className="p-3 rounded-md bg-card/30 border border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              No creators yet
            </p>
          </div>
        </section>

        {/* Recent Uploads */}
        <section>
          <div className="flex items-center gap-2 mb-2">
            <Upload className="h-3.5 w-3.5 text-primary" />
            <h3 className="text-xs font-semibold text-muted-foreground tracking-wider">
              RECENT UPLOADS
            </h3>
          </div>
          <div className="p-3 rounded-md bg-card/30 border border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              No uploads yet
            </p>
          </div>
        </section>
      </div>
    </aside>
  )
}
