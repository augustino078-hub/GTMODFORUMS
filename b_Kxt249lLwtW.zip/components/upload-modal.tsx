"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Upload, X, Loader2, ImageIcon, FileIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import useSWR from "swr"

interface Tag {
  id: string
  name: string
}

interface UploadModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function UploadModal({ open, onOpenChange, onSuccess }: UploadModalProps) {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [modFile, setModFile] = useState<File | null>(null)
  const [thumbnail, setThumbnail] = useState<File | null>(null)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const modInputRef = useRef<HTMLInputElement>(null)
  const thumbnailInputRef = useRef<HTMLInputElement>(null)

  const { data: tagsData } = useSWR<{ tags: Tag[] }>("/api/tags", fetcher)
  const tags = tagsData?.tags || []

  function handleModFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) {
      setModFile(file)
    }
  }

  function handleThumbnailChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) {
      setThumbnail(file)
      const reader = new FileReader()
      reader.onload = () => setThumbnailPreview(reader.result as string)
      reader.readAsDataURL(file)
    }
  }

  function toggleTag(tagName: string) {
    setSelectedTags(prev =>
      prev.includes(tagName)
        ? prev.filter(t => t !== tagName)
        : prev.length < 5
        ? [...prev, tagName]
        : prev
    )
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!modFile) {
      setError("Please select a mod file")
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Upload mod file
      const modFormData = new FormData()
      modFormData.append("file", modFile)
      modFormData.append("type", "mod")

      const modUploadRes = await fetch("/api/upload", {
        method: "POST",
        body: modFormData,
      })

      if (!modUploadRes.ok) {
        const err = await modUploadRes.json()
        throw new Error(err.error || "Failed to upload mod file")
      }

      const { url: fileUrl } = await modUploadRes.json()

      // Upload thumbnail if provided
      let thumbnailUrl = null
      if (thumbnail) {
        const thumbFormData = new FormData()
        thumbFormData.append("file", thumbnail)
        thumbFormData.append("type", "thumbnail")

        const thumbUploadRes = await fetch("/api/upload", {
          method: "POST",
          body: thumbFormData,
        })

        if (thumbUploadRes.ok) {
          const { url } = await thumbUploadRes.json()
          thumbnailUrl = url
        }
      }

      // Create mod entry
      const createRes = await fetch("/api/mods", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          description,
          file_url: fileUrl,
          thumbnail_url: thumbnailUrl,
          tags: selectedTags,
        }),
      })

      if (!createRes.ok) {
        const err = await createRes.json()
        throw new Error(err.error || "Failed to create mod")
      }

      // Reset form
      setName("")
      setDescription("")
      setSelectedTags([])
      setModFile(null)
      setThumbnail(null)
      setThumbnailPreview(null)
      onOpenChange(false)
      onSuccess?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-foreground">Upload Mod</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Mod Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Mod Name</Label>
            <Input
              id="name"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="My Awesome Mod"
              required
              className="bg-secondary border-border"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe what your mod does..."
              required
              rows={3}
              className="bg-secondary border-border resize-none"
            />
          </div>

          {/* Mod File */}
          <div className="space-y-2">
            <Label>Mod File</Label>
            <input
              ref={modInputRef}
              type="file"
              accept=".zip,.dll,.json"
              onChange={handleModFileChange}
              className="hidden"
            />
            <div
              onClick={() => modInputRef.current?.click()}
              className={cn(
                "border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors",
                modFile
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              )}
            >
              {modFile ? (
                <div className="flex items-center justify-center gap-2">
                  <FileIcon className="h-5 w-5 text-primary" />
                  <span className="text-sm text-foreground">{modFile.name}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={e => {
                      e.stopPropagation()
                      setModFile(null)
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Click to upload .zip, .dll, or .json
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Thumbnail */}
          <div className="space-y-2">
            <Label>Thumbnail (optional)</Label>
            <input
              ref={thumbnailInputRef}
              type="file"
              accept="image/*"
              onChange={handleThumbnailChange}
              className="hidden"
            />
            <div
              onClick={() => thumbnailInputRef.current?.click()}
              className={cn(
                "border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors",
                thumbnail
                  ? "border-accent bg-accent/10"
                  : "border-border hover:border-accent/50"
              )}
            >
              {thumbnailPreview ? (
                <div className="relative">
                  <img
                    src={thumbnailPreview}
                    alt="Thumbnail preview"
                    className="max-h-32 mx-auto rounded"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute top-0 right-0 h-6 w-6 p-0"
                    onClick={e => {
                      e.stopPropagation()
                      setThumbnail(null)
                      setThumbnailPreview(null)
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <ImageIcon className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Click to add a thumbnail image
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label>Tags (select up to 5)</Label>
            <div className="flex flex-wrap gap-2">
              {tags.map(tag => (
                <button
                  key={tag.id}
                  type="button"
                  onClick={() => toggleTag(tag.name)}
                  className={cn(
                    "px-2 py-1 rounded text-xs font-medium transition-colors",
                    selectedTags.includes(tag.name)
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                  )}
                >
                  {tag.name}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-md bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={loading || !modFile}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Mod
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
