"use client"

import { Download, BadgeCheck, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"
import Image from "next/image"

export interface ModCardProps {
  id: string
  name: string
  creator: string
  description: string
  thumbnail_url?: string | null
  downloads: number
  tags: string[]
  isVerified?: boolean
  updatedTime: string
}

export function ModCard({
  id,
  name,
  creator,
  description,
  thumbnail_url,
  downloads,
  tags,
  isVerified,
  updatedTime,
}: ModCardProps) {
  const [downloading, setDownloading] = useState(false)

  async function handleDownload(e: React.MouseEvent) {
    e.stopPropagation()
    setDownloading(true)

    try {
      const res = await fetch(`/api/mods/${id}/download`, { method: "POST" })
      if (res.ok) {
        const { file_url } = await res.json()
        window.open(file_url, "_blank")
      }
    } catch (error) {
      console.error("Download failed:", error)
    } finally {
      setDownloading(false)
    }
  }

  function formatDownloads(num: number): string {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  return (
    <div className="group relative rounded-lg border border-border bg-card p-3 hover:border-primary/50 hover:bg-card/80 transition-all duration-200 hover-lift cursor-pointer">
      <div className="flex gap-3">
        {/* Thumbnail */}
        <div className="shrink-0 w-16 h-16 rounded-md bg-secondary overflow-hidden border border-border">
          {thumbnail_url ? (
            <Image
              src={thumbnail_url}
              alt={name}
              width={64}
              height={64}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 via-accent/10 to-highlight/20 flex items-center justify-center">
              <span className="text-muted-foreground text-xs">MOD</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-sm text-foreground truncate group-hover:text-primary transition-colors pr-12">
            {name}
          </h4>
          <div className="flex items-center gap-1 mt-0.5">
            <span className="text-[11px] text-muted-foreground">by</span>
            <span className="text-[11px] text-accent font-medium">{creator}</span>
            {isVerified && (
              <BadgeCheck className="h-3 w-3 text-accent" />
            )}
          </div>
          <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
            {description}
          </p>
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-border/50">
        <div className="flex items-center gap-3">
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="flex items-center gap-1 px-2 py-1 rounded bg-primary/10 hover:bg-primary/20 transition-colors"
          >
            {downloading ? (
              <Loader2 className="h-3 w-3 text-primary animate-spin" />
            ) : (
              <Download className="h-3 w-3 text-primary" />
            )}
            <span className="text-[10px] text-primary font-medium">
              {formatDownloads(downloads)}
            </span>
          </button>
        </div>

        <span className="text-[10px] text-muted-foreground">{updatedTime}</span>
      </div>

      {/* Tags */}
      {tags.length > 0 && (
        <div className="flex gap-1 mt-2 flex-wrap">
          {tags.slice(0, 3).map((tag) => (
            <span 
              key={tag}
              className={cn(
                "text-[9px] px-1.5 py-0.5 rounded",
                tag === "movement" ? "bg-primary/15 text-primary" :
                tag === "gameplay" ? "bg-accent/15 text-accent" :
                tag === "utility" ? "bg-highlight/15 text-highlight" :
                "bg-card text-muted-foreground"
              )}
            >
              {tag}
            </span>
          ))}
          {tags.length > 3 && (
            <span className="text-[9px] text-muted-foreground">+{tags.length - 3}</span>
          )}
        </div>
      )}
    </div>
  )
}
