import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// GET - List all mods
export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const searchParams = request.nextUrl.searchParams
    const tag = searchParams.get("tag")
    const sort = searchParams.get("sort") || "newest"

    let query = supabase
      .from("mods")
      .select(`
        *,
        profiles:user_id (username, avatar_url, is_verified),
        mod_tags (
          tags (name)
        )
      `)

    // Filter by tag if provided
    if (tag) {
      const { data: tagData } = await supabase
        .from("tags")
        .select("id")
        .eq("name", tag)
        .single()

      if (tagData) {
        const { data: modIds } = await supabase
          .from("mod_tags")
          .select("mod_id")
          .eq("tag_id", tagData.id)

        if (modIds) {
          query = query.in("id", modIds.map(m => m.mod_id))
        }
      }
    }

    // Sort
    if (sort === "newest") {
      query = query.order("created_at", { ascending: false })
    } else if (sort === "popular") {
      query = query.order("downloads", { ascending: false })
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching mods:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Transform data to flatten tags
    const mods = data?.map(mod => ({
      ...mod,
      tags: mod.mod_tags?.map((mt: { tags: { name: string } }) => mt.tags.name) || [],
      mod_tags: undefined,
    }))

    return NextResponse.json({ mods })
  } catch (error) {
    console.error("Error fetching mods:", error)
    return NextResponse.json({ error: "Failed to fetch mods" }, { status: 500 })
  }
}

// POST - Create a new mod
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { name, description, file_url, thumbnail_url, tags } = body

    if (!name || !description || !file_url) {
      return NextResponse.json(
        { error: "Name, description, and file are required" },
        { status: 400 }
      )
    }

    // Create the mod
    const { data: mod, error: modError } = await supabase
      .from("mods")
      .insert({
        name,
        description,
        file_url,
        thumbnail_url,
        user_id: user.id,
      })
      .select()
      .single()

    if (modError) {
      console.error("Error creating mod:", modError)
      return NextResponse.json({ error: modError.message }, { status: 500 })
    }

    // Add tags if provided
    if (tags && tags.length > 0) {
      // Get tag IDs
      const { data: tagData } = await supabase
        .from("tags")
        .select("id, name")
        .in("name", tags)

      if (tagData) {
        const modTags = tagData.map(tag => ({
          mod_id: mod.id,
          tag_id: tag.id,
        }))

        await supabase.from("mod_tags").insert(modTags)
      }
    }

    return NextResponse.json({ mod })
  } catch (error) {
    console.error("Error creating mod:", error)
    return NextResponse.json({ error: "Failed to create mod" }, { status: 500 })
  }
}
