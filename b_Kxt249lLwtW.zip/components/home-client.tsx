"use client"

import { useState, Children, cloneElement, isValidElement, ReactNode, ReactElement } from "react"
import { Navbar } from "@/components/navbar"
import { ModGrid } from "@/components/mod-grid"
import { UploadModal } from "@/components/upload-modal"
import { useSWRConfig } from "swr"

interface HomeClientProps {
  user: {
    id: string
    email?: string
    username?: string
  } | null
  children: ReactNode
}

export function HomeClient({ user, children }: HomeClientProps) {
  const [uploadModalOpen, setUploadModalOpen] = useState(false)
  const { mutate } = useSWRConfig()

  function handleUploadSuccess() {
    mutate("/api/mods")
  }

  function handleUploadClick() {
    if (!user) {
      window.location.href = "/auth/login"
      return
    }
    setUploadModalOpen(true)
  }

  // Find the main element and inject ModGrid into it
  function injectModGrid(children: ReactNode): ReactNode {
    return Children.map(children, (child) => {
      if (!isValidElement(child)) return child

      // If this is the main element's inner div (p-4 max-w-4xl), add ModGrid
      if (
        child.type === "div" &&
        typeof child.props.className === "string" &&
        child.props.className.includes("p-4 max-w-4xl")
      ) {
        return cloneElement(child as ReactElement<{ children: ReactNode }>, {
          children: (
            <>
              {child.props.children}
              <ModGrid onUploadClick={handleUploadClick} />
            </>
          ),
        })
      }

      // Recursively process children
      if (child.props?.children) {
        return cloneElement(child as ReactElement<{ children: ReactNode }>, {
          children: injectModGrid(child.props.children),
        })
      }

      return child
    })
  }

  return (
    <>
      <Navbar user={user} onUploadClick={handleUploadClick} />
      {injectModGrid(children)}
      <UploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        onSuccess={handleUploadSuccess}
      />
    </>
  )
}
